var navs = [{
	"title": "内容管理",
	"icon": "fa-cubes",
	"spread": true,
	"children": [{
		"title": "活动1",
		"icon": "&#xe641;",
		"href": "admin.aspx?season=1"
	}, {
	    "title": "活动2",
	    "icon": "&#xe641;",
	    "href": "admin.aspx?season=2"
	},{
		"title": "活动3",
	"icon": "&#xe641;",
	"href": "admin.aspx?season=3"
}
	]
}];